function imgs = testset_standard()
%TESTSET_STANDARD  Build the 14-image 256x256 standard test set.
%
%   imgs = TESTSET_STANDARD() returns a 256x256x14 uint8 array of the
%   standard test images used across the experiments: eight natural
%   images read from the MATLAB installation (cameraman, circuit, rice,
%   moon, trees, indiancorn, printedtext, football) centre-cropped to
%   256x256, plus six synthesised images (ramp, checker, iid_uniform,
%   lowcontrast, constant, halfsplit) that exercise the boundary cases
%   of the security arguments.

    rng(20260930);
    W = 256;
    names = {'cameraman','circuit','rice','moon','trees','indiancorn','printedtext','football'};
    imgs = zeros(W, W, 14, 'uint8');
    for i = 1:8
        im = load_test_image(names{i});
        im = im2uint8(im);
        imgs(:, :, i) = centre_crop(im, W);
    end
    % synthesised images
    imgs(:, :, 9)  = uint8(round(linspace(0, 255, W))' * ones(1, W));          % ramp
    ck = repmat([0 255; 255 0], W/2, W/2);
    imgs(:, :, 10) = uint8(ck);                                                  % checker
    imgs(:, :, 11) = uint8(randi([0 255], W, W));                                % iid_uniform
    imgs(:, :, 12) = uint8(round(128 + 24 * sin(2*pi*(1:W)/W)' * ones(1, W)));   % lowcontrast
    imgs(:, :, 13) = uint8(128 * ones(W, W));                                    % constant
    imgs(:, :, 14) = uint8([zeros(W, W/2), 255*ones(W, W/2)]);                  % halfsplit
end

function im = load_test_image(name)
%LOAD_TEST_IMAGE  Load a MATLAB demo image by name, trying common
%   extensions and the .mat form used for 'trees'.
    base = fullfile(matlabroot, 'toolbox', 'images', 'imdata');
    exts = {'.tif', '.png', '.jpg', '.jpeg'};
    im = [];
    for k = 1:numel(exts)
        p = fullfile(base, [name exts{k}]);
        if exist(p, 'file')
            im = imread(p);
            return;
        end
    end
    % fall back to a .mat variable (e.g. trees.mat holds variable 'trees')
    p = fullfile(base, [name '.mat']);
    if exist(p, 'file')
        S = load(p);
        f = fieldnames(S);
        im = S.(f{1});
        return;
    end
    error('testset_standard:missing', 'cannot locate test image %s', name);
end

function c = centre_crop(im, W)
    [h, w] = size(im);
    if h < W || w < W
        c = imresize(im, [W W]);
        return;
    end
    r0 = floor((h - W)/2) + 1;
    c0 = floor((w - W)/2) + 1;
    c = im(r0:r0+W-1, c0:c0+W-1);
end
