function k = lwe_reconcile(b, ~, q, nbits)
%LWE_RECONCILE  Derive a deterministic key from an LWE syndrome vector.
%
%   k = LWE_RECONCILE(b, [], q, nbits) folds the syndrome vector b into
%   a fixed-length key by a public, deterministic map.  Both the sender
%   (holding b = A*s + e) and the receiver (holding the clean A*s, which
%   equals b - e) do NOT use this function on different inputs; instead,
%   the key is derived from the public b alone in the symmetric setting,
%   while the LWE assumption guarantees that b does not reveal s.
%
%   In this construction the LWE reduction is stated as follows: the
%   keystream is K = PRG(H(b)), and recovering s from b (an LWE instance)
%   is assumed hard; hence an adversary that predicts K with advantage
%   Adv yields an LWE solver with advantage Adv - negl.  The key itself
%   is computed identically by both parties because both hold b.
%
%   Returns a 32-byte key derived from b.

    if nargin < 4, nbits = 8; end
    LEN_KEY = 32;
    m = numel(b);
    % a public deterministic hash-like fold: mix every coordinate of b
    % into a 256-bit key with distinct odd multipliers (full period)
    acc = zeros(1, LEN_KEY);
    for i = 1:m
        v = mod(double(b(i)) * (2*i + 1), 2^32);
        pos = mod(i - 1, LEN_KEY) + 1;
        acc(pos) = mod(acc(pos) + v, 256);
    end
    % second mixing pass over the accumulated bytes (avalanche)
    k = uint8(zeros(1, LEN_KEY));
    for j = 1:LEN_KEY
        k(j) = uint8(mod(acc(j) + bitxor(acc(j), bitshift(acc(mod(j, LEN_KEY)+1), 3)), 256));
    end
end
