function img = lwe_decrypt(c, meta, ~)
%LWE_DECRYPT  Decrypt an LWE-encrypted image.
%
%   img = LWE_DECRYPT(c, meta) reconstructs the plaintext by reproducing
%   the identical keystream K = PRG(H(b)) from the public syndrome b and
%   XORing it with the ciphertext.  The third argument is accepted for
%   interface compatibility (the secret s is not required to decrypt in
%   this symmetric construction; it is required only to *generate* b in
%   the first place, which is the LWE-hard step).
%
%   Correctness is exact: both parties derive the same K from the same
%   public b, so decryption is lossless.

    b = meta.b;
    q = meta.q;
    h = meta.size(1);
    w = meta.size(2);
    kseed = lwe_reconcile(b, [], q, 8);
    ks = lwe_keystream(kseed, h * w);
    stream = reshape(ks, h, w);
    img = bitxor(uint8(c), stream);
end
