function adv = lwe_solve_advantage(n, q, sigma)
%LWE_SOLVE_ADVANTAGE  Heuristic advantage of solving an LWE instance.
%
%   adv = LWE_SOLVE_ADVANTAGE(n, q, sigma) returns the estimated
%   advantage of a lattice-reduction (BKZ) attack against an LWE
%   instance of dimension n, modulus q and noise standard deviation
%   sigma.  The estimate follows the standard heuristic: the attack
%   succeeds when the reduced-basis quality root-Hermite factor delta
%   satisfies
%
%        delta^n  ~  q * (sigma / sqrt(2*pi))  ,
%
%   and the success advantage is modelled as a logistic function of the
%   distance to this threshold.  As n grows, the required block size
%   grows and the advantage falls off rapidly.
%
%   This is the reference curve used in Theorem A: the measured
%   ciphertext distinguishing advantage must decay at least as fast as
%   this quantity.

    if nargin < 3, sigma = 3.2; end
    % target root-Hermite factor from the success condition (log form)
    % log(delta) = (1/n) * log( q * sigma / sqrt(2*pi) )
    logdelta = log(q * sigma / sqrt(2*pi)) / n;
    % BKZ block size beta needed to reach this delta (heuristic:
    % log(delta) ~ log(beta)/(2 beta) => beta ~ 2 * n * logdelta / ... )
    % use the standard approximate inversion
    if logdelta <= 0
        beta = n;               % trivially hard at the limit
    else
        % solve  log(delta) = (log beta)/(2 beta)  approximately
        beta = max(2, round(2 * log(2) / logdelta));
        beta = min(beta, n);
    end
    % logistic advantage: near 1 when beta is tiny, near 0 when beta ~ n
    adv = 1 ./ (1 + exp((beta - 20) / 8));
    % clamp to a small floor so the curve stays interpretable
    adv = max(adv, 1e-12);
end
