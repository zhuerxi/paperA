function [A, s, e, b] = lwe_keygen(n, m, q, sigma)
%LWE_KEYGEN  Sample an LWE instance and encapsulate a key.
%
%   [A, s, e, b] = LWE_KEYGEN(n, m, q, sigma) draws the public matrix
%   A in Z_q^{m x n} uniformly at random, a secret vector s in Z_q^n,
%   a discrete-Gaussian noise vector e of standard deviation sigma, and
%   returns the syndrome b = A*s + e (mod q).
%
%   The pair (A, b) is public; (s, e) is secret.  The reconciliation
%   step is performed separately by LWE_RECONCILE.
%
%   See also LWE_RECONCILE, LWE_SOLVE_ADVANTAGE.

    if nargin < 4, sigma = 3.2; end
    A = randi([0, q-1], m, n);
    s = randi([0, q-1], n, 1);
    % discrete Gaussian noise rounded to integers
    e = round(sigma * randn(m, 1));
    b = mod(A * s + e, q);
end
