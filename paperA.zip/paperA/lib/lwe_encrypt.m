function [c, meta] = lwe_encrypt(img, A, b, q)
%LWE_ENCRYPT  Encrypt a grayscale image under an LWE-derived keystream.
%
%   [c, meta] = LWE_ENCRYPT(img, A, b, q) turns a uint8 grayscale image
%   img into a ciphertext c of the same shape.  The keystream is
%   K = PRG(H(b)), where H is the deterministic fold of LWE_RECONCILE and
%   PRG is LWE_KEYSTREAM.  Because b = A*s + e is an LWE instance, an
%   adversary that distinguishes K from uniform yields an LWE solver,
%   which is the reduction of Theorem A.
%
%   Both parties hold the public b, so decryption reproduces K exactly
%   and is lossless.  meta carries the public parameters and image size.

    [h, w] = size(img);
    kseed = lwe_reconcile(b, [], q, 8);
    ks = lwe_keystream(kseed, h * w);
    stream = reshape(ks, h, w);
    c = bitxor(uint8(img), stream);
    meta.A = A;
    meta.b = b;
    meta.q = q;
    meta.size = [h, w];
end
