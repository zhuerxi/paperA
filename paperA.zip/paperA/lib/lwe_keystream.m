function ks = lwe_keystream(seed_bytes, L)
%LWE_KEYSTREAM  Expand a 32-byte key into an L-byte keystream via a PRG.
%
%   ks = LWE_KEYSTREAM(seed_bytes, L) implements a deterministic
%   pseudorandom generator built on the SplitMix32 construction.  All
%   arithmetic is performed in uint64, where multiplication of two
%   32-bit quantities cannot overflow, and the low 32 bits are taken
%   after each step; this reproduces the exact wrap-around semantics of
%   C, avoiding MATLAB's saturating integer overflow.
%
%   A single seed-bit difference avalanches across the output, and the
%   output is statistically uniform.
%
%   Note: this PRG is a pedagogical stand-in.  In a deployment the
%   keystream should be produced by a NIST-approved PRG such as AES in
%   counter mode or SHAKE; the security claim of the paper rests on the
%   LWE reduction, not on this expansion step.

    if nargin < 2, L = 256*256; end
    nw = 4;
    MASK = uint64(0xFFFFFFFF);
    % fold the 32 seed bytes into four 32-bit words (uint64 to avoid saturation)
    st = uint64(zeros(1, nw));
    for i = 1:numel(seed_bytes)
        w = mod(i - 1, nw) + 1;
        st(w) = bitand(st(w) + uint64(seed_bytes(i)) * uint64(2654435761) * uint64(i), MASK);
    end
    for w = 1:nw
        if st(w) == 0, st(w) = uint64(0x9E3779B9 + w); end
    end
    ks = zeros(L, 1, 'uint8');
    for j = 1:L
        w = mod(j - 1, nw) + 1;
        z = st(w);
        z = bitand(z + uint64(0x9E3779B9), MASK);
        z = bitand(bitxor(z, bitshift(z, 16)), MASK);
        z = bitand(z * uint64(0x85EBCA6B), MASK);
        z = bitand(bitxor(z, bitshift(z, 13)), MASK);
        z = bitand(z * uint64(0xC2B2AE35), MASK);
        z = bitand(bitxor(z, bitshift(z, 16)), MASK);
        st(w) = z;
        ks(j) = uint8(bitshift(z, -24));
    end
end
