function make_figs_en()
%MAKE_FIGS_EN  Regenerate the English-labelled figures for Paper A.
%
%   Reads the cached results in out/ and writes the six English-labelled
%   figures into out/en/ as PNG and TIFF.  No experiments are re-run.

    outdir = fullfile('out', 'en');
    if ~exist(outdir, 'dir'), mkdir(outdir); end
    W = [720 460];

    % Fig 1: Theorem A falsification (advantage vs dimension)
    S = load('out/thmA_advantage.mat');
    f = figure('Visible','off','Position',[100 100 W]);
    semilogy(S.ns, S.adv_meas, 'o-', 'LineWidth', 1.6, ...
        'MarkerFaceColor', [0.15 0.35 0.75], 'Color', [0.15 0.35 0.75]);
    hold on;
    semilogy(S.ns, S.adv_ref, 's--', 'LineWidth', 1.6, ...
        'MarkerFaceColor', [0.85 0.25 0.25], 'Color', [0.85 0.25 0.25]);
    set(gca, 'YScale', 'log');
    xlabel('LWE dimension n', 'Interpreter', 'tex');
    ylabel('Advantage (log)', 'Interpreter', 'tex');
    legend({'Measured ciphertext advantage', ...
        'Reference LWE-solving advantage (BKZ)'}, 'Location', 'northeast');
    title('Theorem A: distinguishing advantage vs dimension');
    grid on;
    print(f, fullfile(outdir, 'figA1_advantage.png'), '-dpng', '-r300');
    print(f, fullfile(outdir, 'figA1_advantage.tif'), '-dtiff', '-r300');
    close(f);

    % Fig 2: decryption correctness (MSE = 0 across the test set)
    T = readtable('out/thmA_correctness.csv');
    f = figure('Visible','off','Position',[100 100 W]);
    semilogy(T.image, T.MSE + eps, 'o-', 'LineWidth', 1.6, ...
        'MarkerFaceColor', [0.15 0.55 0.35], 'Color', [0.15 0.55 0.35]);
    xlabel('Test image index', 'Interpreter', 'tex');
    ylabel('Mean squared error (log)', 'Interpreter', 'tex');
    title('Lossless decryption (MSE = 0) across the 14-image test set');
    grid on;
    print(f, fullfile(outdir, 'figA2_correctness.png'), '-dpng', '-r300');
    print(f, fullfile(outdir, 'figA2_correctness.tif'), '-dtiff', '-r300');
    close(f);

    % Fig 3: ciphertext entropy histogram (uniformity)
    S = load('out/thmA_uniformity.mat');
    f = figure('Visible','off','Position',[100 100 W]);
    histogram(S.ent, 12, 'FaceColor', [0.55 0.35 0.75], 'EdgeColor', 'w');
    xlabel('Ciphertext entropy (bits/pixel)', 'Interpreter', 'tex');
    ylabel('Count', 'Interpreter', 'tex');
    title('Ciphertext entropy across the 14-image test set');
    grid on;
    print(f, fullfile(outdir, 'figA3_entropy.png'), '-dpng', '-r300');
    print(f, fullfile(outdir, 'figA3_entropy.tif'), '-dtiff', '-r300');
    close(f);

    % Fig 4: superiority (LWE vs logistic entropy)
    T = readtable('out/thmA_superiority.csv');
    f = figure('Visible','off','Position',[100 100 W]);
    plot(T.image, T.LWE_entropy, 'o-', 'LineWidth', 1.5, ...
        'MarkerFaceColor', [0.15 0.35 0.75], 'Color', [0.15 0.35 0.75]);
    hold on;
    plot(T.image, T.logistic_entropy, 's-', 'LineWidth', 1.5, ...
        'MarkerFaceColor', [0.85 0.25 0.25], 'Color', [0.85 0.25 0.25]);
    yline(8, 'k--', 'LineWidth', 0.8);
    xlabel('Test image index', 'Interpreter', 'tex');
    ylabel('Ciphertext entropy (bits/pixel)', 'Interpreter', 'tex');
    legend({'Proposed LWE scheme', 'Logistic baseline', 'Ideal (8.0)'}, ...
        'Location', 'southeast');
    title('Ciphertext entropy: proposed vs baseline');
    grid on;
    print(f, fullfile(outdir, 'figA4_superiority.png'), '-dpng', '-r300');
    print(f, fullfile(outdir, 'figA4_superiority.tif'), '-dtiff', '-r300');
    close(f);

    % Fig 5: noise robustness (BER vs channel flip rate)
    T = readtable('out/thmA_robustness.csv');
    f = figure('Visible','off','Position',[100 100 W]);
    loglog(T.flip_rate, T.BER, 'o-', 'LineWidth', 1.6, ...
        'MarkerFaceColor', [0.85 0.55 0.15], 'Color', [0.85 0.55 0.15]);
    xlabel('Channel bit-flip rate', 'Interpreter', 'tex');
    ylabel('Recovered bit-error rate (BER)', 'Interpreter', 'tex');
    title('Recovery error vs channel noise (no error correction)');
    grid on;
    print(f, fullfile(outdir, 'figA5_robustness.png'), '-dpng', '-r300');
    print(f, fullfile(outdir, 'figA5_robustness.tif'), '-dtiff', '-r300');
    close(f);

    fprintf('[make_figs_en] wrote 5 figures to %s\n', outdir);
end
