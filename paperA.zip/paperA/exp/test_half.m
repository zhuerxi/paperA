function test_half()
here = fileparts(mfilename('fullpath'));
addpath(fullfile(here, '..', 'lib'));
P = testset_standard();
names = {'cameraman','circuit','rice','moon','trees','indiancorn','printedtext','football','ramp','checker','iid_uniform','lowcontrast','constant','halfsplit'};
for k = 1:14
    I = P(:, :, k);
    fprintf('idx=%2d name=%-12s min=%3d max=%3d nunique=%3d\n', k, names{k}, min(I(:)), max(I(:)), numel(unique(I(:))));
end
end
