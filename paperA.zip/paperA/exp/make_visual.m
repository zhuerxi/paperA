function make_visual()
%MAKE_VISUAL  Generate the plaintext/ciphertext/decrypted visual panel for Paper A.
%
%   Produces a single figure showing, for two representative images, the
%   original plaintext, its histogram, the ciphertext, its histogram, the
%   decrypted image and its histogram, demonstrating the visual effect of
%   the LWE encryption and the losslessness of decryption.

    here = fileparts(mfilename('fullpath'));
    addpath(fullfile(here, '..', 'lib'));
    outdir = fullfile(here, 'out', 'en');
    if ~exist(outdir, 'dir'), mkdir(outdir); end

    % LWE parameters (match run_thmA_lwe.m)
    q = 257; n = 256; m = 512; sigma = 3.2;
    rng(20261103);

    % Representative images: a natural image (cameraman) and a structured
    % two-tone boundary image (halfsplit), the worst case for a bytewise XOR
    % stream cipher.
    P = testset_standard();
    names = {'cameraman', 'halfsplit'};
    idx = [1, 14];

    f = figure('Visible', 'off', 'Position', [50 50 1100 680], 'Color', 'w');

    for k = 1:numel(names)
        img = P(:, :, idx(k));
        [A, s, e, b] = lwe_keygen(n, m, q, sigma); %#ok<ASGLU>
        [c, meta] = lwe_encrypt(img, A, b, q);
        d = lwe_decrypt(c, meta);
        mse = mean((double(img(:)) - double(d(:))).^2); %#ok<NASGU>

        % plaintext
        subplot(2, 6, (k-1)*6 + 1);
        imshow(img, []); title(sprintf('Plaintext: %s', names{k}), 'FontSize', 9);
        subplot(2, 6, (k-1)*6 + 2);
        draw_hist(img, [0.25 0.35 0.6]); title('Plaintext histogram', 'FontSize', 9);

        % ciphertext
        subplot(2, 6, (k-1)*6 + 3);
        imshow(c, []); title('Ciphertext', 'FontSize', 9);
        subplot(2, 6, (k-1)*6 + 4);
        draw_hist(c, [0.7 0.2 0.2]); title('Ciphertext histogram', 'FontSize', 9);

        % decrypted
        subplot(2, 6, (k-1)*6 + 5);
        imshow(d, []); title('Decrypted', 'FontSize', 9);
        subplot(2, 6, (k-1)*6 + 6);
        draw_hist(d, [0.2 0.5 0.3]); title('Decrypted histogram', 'FontSize', 9);
    end

    sgtitle('Paper A: plaintext \rightarrow ciphertext \rightarrow decrypted (LWE stream cipher)', ...
        'FontSize', 12);

    print(f, fullfile(outdir, 'figA8_visual.png'), '-dpng', '-r300');
    close(f);
    fprintf('[make_visual] wrote figA8_visual (Paper A) to %s\n', outdir);
end

function draw_hist(img, color)
% draw a coarse 32-bin histogram so that both natural images and two-tone
% images (e.g. halfsplit) show their structure visibly at print resolution.
    v = double(img(:));
    edges = linspace(0, 256, 33);   % 32 bins over [0,255]
    histogram(v, edges, 'FaceColor', color, 'EdgeColor', 'none');
    xlim([0 255]);
    set(gca, 'YTick', []);
end
